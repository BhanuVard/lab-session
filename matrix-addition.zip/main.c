#include<stdio.h>
int main()
{
    int matrix1[10][10], matrix2[10][10], matrixadd[10][10];
    int x,y,i,j;
    printf("Enter row size:");
    scanf("%d",&x);
    printf("Enter column size:");
    scanf("%d",&y);
    printf("\nEnter elements of first matrix:");
    for(i=0; i<x; i++)
    {
        for(j=0; j<y; j++)
            scanf("%d", &matrix1[i][j]);
    }
    printf("Enter elements of second matrix:");
    for(i=0; i<x; i++)
    {
        for(j=0; j<y; j++)
            scanf("%d", &matrix2[i][j]);
    }
    for(i=0; i<x; i++)
    {
        for(j=0;j<y; j++)
            matrixadd[i][j] =matrix1[i][j]+matrix2[i][j];
    }
    printf("\nThe matrix after addition:\n");
    for(i=0;i<x; i++)
    {
        for(j=0; j<y; j++)
            printf("%d ",matrixadd[i][j]);
        printf("\n");
    }

    return 0;
}
  


